#' @title Re-export of `as.data.table`
#'
#' See [data.table::as.data.table].
#'
#' @name as.data.table
#' @rdname as.data.table
#' @keywords internal
#' @export
NULL

library(testthat)
library(mlr3viz)

test_check("mlr3viz")

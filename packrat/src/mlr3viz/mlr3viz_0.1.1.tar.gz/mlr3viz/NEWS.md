# mlr3viz 0.1.1

- New plot: learner prediction for objects of class `ResampleResult`.
  Additionally, the helper function `plot_learner_prediction()` first performs a
  `resample()` and then plots the result.
- New plot: residual plot for objects of class `PredictionRegr`.

# mlr3viz 0.1.0

- Initial CRAN release

#' @title Re-export of `autoplot`
#'
#' See [ggplot2::autoplot()].
#'
#' @name autoplot
#' @rdname autoplot
#' @keywords internal
#' @export
NULL

#' @title Re-export of `fortify`
#'
#' See [ggplot2::fortify()].
#'
#' @name fortify
#' @rdname fortify
#' @keywords internal
#' @export
NULL

library(testthat)
library(paradox)

test_check("paradox")

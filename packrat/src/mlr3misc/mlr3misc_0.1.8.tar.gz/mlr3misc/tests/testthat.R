if (requireNamespace("testthat", quietly = TRUE)) {
  library(testthat)
  library(mlr3misc)
  test_check("mlr3misc")
}

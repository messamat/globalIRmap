tab = mlr3verse::mlr3verse_info()
stopifnot(is.data.frame(tab))

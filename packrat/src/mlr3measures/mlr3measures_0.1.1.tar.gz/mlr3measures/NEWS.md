# mlr3measures 0.1.1

* Added new measure `bacc` (Balanced Accuracy).
* Fixed some tests which stochastically failed.
* The name of the measure is now also stored in the meta data.

# mlr3measures 0.1.0

Initial release.

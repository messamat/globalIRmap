#' @importFrom utils head
#' @importFrom stats cor median var relevel
#' @import checkmate
"_PACKAGE"

library(testthat)
library(OOBCurve)

test_check("OOBCurve")

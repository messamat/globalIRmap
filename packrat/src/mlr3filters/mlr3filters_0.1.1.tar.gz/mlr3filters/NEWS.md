# mlr3filters 0.1.1

* Replace dependency `Metrics` with `mlr3measures`.

# mlr3filters 0.1.0

* Initial CRAN release.

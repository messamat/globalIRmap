f <- function() {

  pause(0.1)
}

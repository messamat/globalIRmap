if (requireNamespace("testthat", quietly = TRUE)) {
  library(testthat)
  library(mlr3db)
  test_check("mlr3db")
}
